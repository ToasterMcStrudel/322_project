﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _322_Foodie_Fighters
{
    static public class Chef_Duties
    {
        class Chef
        {
            public Boolean readyForOrder;
            public void stopCookingTimer()
            {
                throw new NotImplementedException("Not yet implemented"); //TO-DO
            }
            public Order deleteOrder(Order o)
            {
                throw new NotImplementedException("Not yet implemented"); //TO-DO
            }
            public Order completeOrder(Order o)
            {
                throw new NotImplementedException("Not yet implemented"); //TO-DO
            }


        }

        static public void reportToWaitstaff(Order o)
        {

        }
        static private Order deleteOrder(Order o)
        {
            throw new NotImplementedException("Not yet implemented"); //TO-DO
        }
        static private void completeOrder(Order o)
        {

        }
    }
}
          