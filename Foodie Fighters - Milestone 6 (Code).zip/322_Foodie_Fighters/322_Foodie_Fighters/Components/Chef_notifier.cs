﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _322_Foodie_Fighters
{
    static public class ChefNotifier
    {
        public class CookingTimer
        {
            public Dictionary<Order, double> expectedTimesOfOrders;
            string time;
            double timeLeft;
            //throw new NotImplementedException("Not yet implemented"); //TO-DO

            public void startTimer()
            {

            }
            public void stopTimer()
            {

            }
            public void clearTimer()
            {

            }
        }

        static public void stopCookingTimer()
        {

        }
        static public void resetCookingTimer()
        {

        }
        static public void startCookingTimer(double time)
        {

        }

    }
}
