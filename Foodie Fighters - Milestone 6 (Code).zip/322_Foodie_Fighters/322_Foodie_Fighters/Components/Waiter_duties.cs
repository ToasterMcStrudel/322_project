﻿             using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _322_Foodie_Fighters
{
    static public class WaiterDuties
    {

        static public void displayMenu()
        {
            //Print from database menu
        }
        static private Dish[] addOrder(Dish d)
        {
            throw new NotImplementedException("Not yet implemented"); //TO-DO
        }
        static private Dish[] removeOrder(Dish d)
        {
            throw new NotImplementedException("Not yet implemented"); //TO-DO
        }
        static private double deliverCollectBill(Dish[] fullMeal)
        {
            throw new NotImplementedException("Not yet implemented"); //TO-DO
        }
        static private int tellCookingTimerOrder(Dish[] fullMeal)
        {
            throw new NotImplementedException("Not yet implemented"); //TO-DO
        }

    }
}
